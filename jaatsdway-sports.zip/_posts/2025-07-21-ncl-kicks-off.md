---
title: NCL 2025 Kicks Off
---

The Netherlands Cricket League begins with exciting fixtures this week!
